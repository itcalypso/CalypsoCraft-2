playsound minecraft:block.iron_trapdoor.close ambient @a -343 67 687
playsound minecraft:block.glass.break ambient @a -343 67 687
tellraw @a[tag=sq.hopbox.opener] [{"text":"You activated a poison trap!","color":"gray"}]
effect give @a[tag=sq.hopbox.opener] minecraft:poison 10
tag @a[tag=sq.hopbox.opener] remove sq.hopbox.opener
tag e758065c-be20-4dad-ab62-6040b9c3d65c remove cooldown
scoreboard objectives remove sq.chest.roll
scoreboard objectives remove sq.chest.target
scoreboard objectives remove sq.chest.critfail
