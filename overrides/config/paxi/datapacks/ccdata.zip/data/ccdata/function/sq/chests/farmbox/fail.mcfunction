playsound minecraft:block.iron_trapdoor.close ambient @a -309 63 697
tellraw @a[tag=sq.farmbox.opener] [{"text":"You fail to pick the lock.","color":"gray"}]
tag @a[tag=sq.farmbox.opener] remove sq.farmbox.opener
tag baf3c863-5fe4-4eee-b194-66d46aa0becb remove cooldown
scoreboard objectives remove sq.farmbox.roll
scoreboard objectives remove sq.farmbox.target
