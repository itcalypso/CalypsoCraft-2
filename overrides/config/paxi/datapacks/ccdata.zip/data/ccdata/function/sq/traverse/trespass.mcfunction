tag @s add sq.trespass
execute at @s run playsound cc_customs:alert hostile
tellraw @s [{"text":"Blockup Co. Security says: ","color":"yellow"},{"text":"Trespasser! Get 'em!","color":"white"}]
schedule function ccdata:sq/traverse/boot 48t
