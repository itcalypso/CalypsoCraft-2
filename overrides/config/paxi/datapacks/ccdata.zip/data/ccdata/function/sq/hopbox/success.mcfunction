give @a[tag=sq.hopbox.opener] kubejs:access_pass 1
playsound minecraft:block.chest.open ambient @a[distance=..4] -157 87 948
tellraw @a[tag=sq.hopbox.opener] [{"text":"You find an employee badge.","color":"gray"}]
tag @a[tag=sq.hopbox.opener] remove sq.hopbox.opener
tag e758065c-be20-4dad-ab62-6040b9c3d65c remove cooldown
scoreboard objectives remove sq.chest.roll
scoreboard objectives remove sq.chest.target
scoreboard objectives remove sq.chest.critfail
