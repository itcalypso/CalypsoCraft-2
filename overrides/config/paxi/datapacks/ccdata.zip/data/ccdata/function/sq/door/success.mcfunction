playsound minecraft:block.wooden_door.open ambient @a -340 63 686
tp @a[tag=sq.door.opener] -340 63 686 30 0
tellraw @a[tag=sq.door.opener] [{"text":"You pick the lock and sneak through.","color":"gray"}]
tag @a[tag=sq.door.opener] remove sq.door.opener
tag b37fcc37-3b21-4092-92cc-03a77af71cd5 remove cooldown
