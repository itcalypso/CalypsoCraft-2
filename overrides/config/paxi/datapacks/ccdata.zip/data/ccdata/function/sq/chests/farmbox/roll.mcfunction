tag @s add sq.farmbox.opener
tellraw @s [{"text":"You attempt to pick the lock...","color":"gray"}]
scoreboard objectives add sq.farmbox.roll dummy
scoreboard objectives add sq.farmbox.target dummy
scoreboard players add @s sq.farmbox.target 40
execute store result score @s sq.farmbox.roll run random value 1..100
scoreboard players operation @s sq.farmbox.roll += @s stealth.bonus
execute if score @s sq.farmbox.roll >= @s sq.farmbox.target run schedule function ccdata:sq/chests/farmbox/success 48t
execute if score @s sq.farmbox.roll < @s sq.farmbox.target run schedule function ccdata:sq/chests/farmbox/fail 48t
