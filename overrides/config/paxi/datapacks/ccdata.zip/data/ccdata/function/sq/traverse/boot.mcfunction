tp @a[tag=sq.trespass] -268 64 694 115 0
tellraw @a[tag=sq.trespass] [{"text":"The guards beat you up and kicked you out.","color":"gray"}]
execute as @a[tag=sq.trespass] run damage @s 4 minecraft:mob_attack by d946fa0f-2328-4095-ab24-7305c13027c9
execute at @a[tag=sq.trespass] run playsound minecraft:entity.generic.explode hostile @a ~ ~ ~
effect give @a[tag=sq.trespass] minecraft:blindness 2
execute as @a[tag=sq.trespass] run tag @s remove sq.trespass
