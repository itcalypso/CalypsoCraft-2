playsound minecraft:block.iron_trapdoor.close ambient @a -333 64 666
tellraw @a[tag=sq.factorybox.opener] ["",{"text":"Blockup Co. Security says:","color":"yellow"}," What do you think you're doing? Stop that!"]
tag @a[tag=sq.factorybox.opener] add sq.trespass
function ccdata:sq/traverse/boot
tag @a[tag=sq.factorybox.opener] remove sq.factorybox.opener
tag ba6212b5-f345-44a5-98cf-908a17210bc4 remove cooldown
scoreboard objectives remove sq.factorybox.roll
scoreboard objectives remove sq.factorybox.target
scoreboard objectives remove sq.factorybox.critfail
