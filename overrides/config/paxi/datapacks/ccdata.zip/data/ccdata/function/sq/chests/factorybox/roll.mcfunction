tag @s add sq.factorybox.opener
tellraw @s [{"text":"You attempt to pick the lock...","color":"gray"}]
scoreboard objectives add sq.factorybox.roll dummy
scoreboard objectives add sq.factorybox.target dummy
scoreboard objectives add sq.factorybox.critfail dummy
scoreboard players add @s sq.factorybox.target 50
scoreboard players add @s sq.factorybox.critfail 12
execute store result score @s sq.factorybox.roll run random value 1..100
scoreboard players operation @s sq.factorybox.roll += @s stealth.bonus
execute if score @s sq.factorybox.roll <= @s sq.factorybox.critfail run return run schedule function ccdata:sq/chests/factorybox/critfail 48t
execute if score @s sq.factorybox.roll < @s sq.factorybox.target run schedule function ccdata:sq/chests/factorybox/fail 48t
execute if score @s sq.factorybox.roll >= @s sq.factorybox.target run schedule function ccdata:sq/chests/factorybox/success 48t
