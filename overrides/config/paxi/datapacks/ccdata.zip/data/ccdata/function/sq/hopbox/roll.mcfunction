tag @s add sq.hopbox.opener
tellraw @s [{"text":"You attempt to pick the lock...","color":"gray"}]
scoreboard objectives add sq.chest.roll dummy
scoreboard objectives add sq.chest.target dummy
scoreboard objectives add sq.chest.critfail dummy
scoreboard players add @s sq.chest.target 70
scoreboard players add @s sq.chest.critfail 30
execute store result score @s sq.chest.roll run random value 1..100
scoreboard players operation @s sq.chest.roll += @s stealth.bonus
execute if score @s sq.chest.roll <= @s sq.chest.critfail run return run schedule function ccdata:sq/hopbox/critfail 48t
execute if score @s sq.chest.roll < @s sq.chest.target run schedule function ccdata:sq/hopbox/fail 48t
execute if score @s sq.chest.roll >= @s sq.chest.target run schedule function ccdata:sq/hopbox/success 48t
