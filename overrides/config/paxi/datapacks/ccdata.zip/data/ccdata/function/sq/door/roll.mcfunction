tag @s add sq.door.opener
tellraw @s [{"text":"You attempt to pick the door's lock...","color":"gray"}]
execute if items entity @s weapon.mainhand kubejs:lockpick run schedule function ccdata:sq/door/success 48t
execute unless items entity @s weapon.mainhand kubejs:lockpick run schedule function ccdata:sq/door/fail 48t
