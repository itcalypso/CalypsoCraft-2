tp @a[tag=cm.chest.opener] -154 64 971 -125 -15
playsound minecraft:entity.illusioner.mirror_move ambient @a -153 64 971
tellraw @a[tag=cm.chest.opener] [{"text":"You activated a teleport trap!","color":"gray"}]
tag @a[tag=cm.chest.opener] remove cm.chest.opener
tag 43aab7a7-55d7-48ba-9177-be6d12dabc2b remove chest.cooldown
scoreboard objectives remove cm.chest.roll
scoreboard objectives remove cm.chest.target
