playsound minecraft:block.iron_trapdoor.close ambient @a -340 63 680
tellraw @a[tag=sq.door.opener] [{"text":"But you didn't have a lockpick...","color":"gray"}]
tag @a[tag=sq.door.opener] remove sq.door.opener
tag b37fcc37-3b21-4092-92cc-03a77af71cd5 remove cooldown
