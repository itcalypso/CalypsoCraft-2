loot give @a[tag=sq.factorybox.opener] loot ccdata:factorychest
playsound minecraft:block.chest.open ambient @a[distance=..4] -333 63 666
tellraw @a[tag=sq.factorybox.opener] [{"text":"You find some loot.","color":"gray"}]
tag @a[tag=sq.factorybox.opener] remove sq.factorybox.opener
tag ba6212b5-f345-44a5-98cf-908a17210bc4 remove cooldown
scoreboard objectives remove sq.factorybox.roll
scoreboard objectives remove sq.factorybox.target
