tag @s add sq.trespass
execute at @s run playsound cc_customs:alert hostile
tellraw @s [{"text":"John Head-of-Personnel says: ","color":"yellow"},{"text":"Somebody snuck in the office! SECURITY!","color":"white"}]
schedule function ccdata:sq/traverse/boot 48t
