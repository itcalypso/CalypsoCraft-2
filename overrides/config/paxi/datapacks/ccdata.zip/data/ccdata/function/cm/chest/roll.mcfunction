tag @s add cm.chest.opener
tellraw @s [{"text":"You attempt to pick the lock...","color":"gray"}]
scoreboard objectives add cm.chest.roll dummy
scoreboard objectives add cm.chest.target dummy
scoreboard players add @s cm.chest.target 51
execute store result score @s cm.chest.roll run random value 1..100
scoreboard players operation @s cm.chest.roll += @s stealth.bonus
execute if score @s cm.chest.roll >= @s cm.chest.target run schedule function ccdata:cm/chest/success 48t
execute if score @s cm.chest.roll < @s cm.chest.target run schedule function ccdata:cm/chest/fail 48t
