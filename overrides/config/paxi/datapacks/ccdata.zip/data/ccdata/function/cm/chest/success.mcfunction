loot give @a[tag=cm.chest.opener] loot ccdata:thief_coalmine_chest
playsound minecraft:block.chest.open ambient @a[distance=..4] -157 87 948
tellraw @a[tag=cm.chest.opener] [{"text":"You find some loot.","color":"gray"}]
tag @a[tag=cm.chest.opener] remove cm.chest.opener
tag 43aab7a7-55d7-48ba-9177-be6d12dabc2b remove chest.cooldown
scoreboard objectives remove cm.chest.roll
scoreboard objectives remove cm.chest.target
